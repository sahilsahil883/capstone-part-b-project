This folder stores screenshots and evidence supporting weekly project logs.
