This folder contains implementation artefacts for the project MVP.
