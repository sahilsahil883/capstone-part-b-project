This folder contains project documentation and planning artefacts.
